package GuiComponent;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.lang.Math;

public class MainFrame extends JFrame implements ActionListener {
    private JPanel cards;

    // Create Panel
    private JPanel MainCard;
    private JPanel SubCard;
    private JPanel SubCard1;
    private JPanel SubCard2;
    private JPanel SubCard3;
    private JPanel SubCard4;

    private static final String ARITHMETICCARD = "Arithmetic";
    private static final String TRIGONOMETRYCARD = "Trigonometry";
    private static final String BITWISECARD = "Bitwise";
    private static final String BINARYARITHMETICCARD = "Binary_Arithmetic";
    private static final String MONEYEXCHANGECARD = "Money_Exchange";
    private static final String NUMBERSYSTEMCONVERSIONCARD = "Number_System_Conversion";

    // Create button for Arithmetic panel
    private JButton btnZeroInArithmetic;
    private JButton btnOneInArithmetic;
    private JButton btnTwoInArithmetic;
    private JButton btnThreeInArithmetic;
    private JButton btnFourInArithmetic;
    private JButton btnFiveInArithmetic;
    private JButton btnSixInArithmetic;
    private JButton btnSevenInArithmetic;
    private JButton btnEightInArithmetic;
    private JButton btnNineInArithmetic;
    private JButton btnEqualInArithmetic;
    private JButton btnDivisionInArithmetic;
    private JButton btnAdditionInArithmetic;
    private JButton btnSubtractionInArithmetic;
    private JButton btnModuloInArithmetic;
    private JButton btnClearInArithmetic;
    private JButton btnBackspaceInArithmetic;
    private JButton btnMultiplyInArithmetic;
    private JButton btnDotInArithmetic;
    private JButton btnOneOverXInArithmetic;
    private JButton btnX2InArithmetic;
    private JButton btnRadicalX2InArithmetic;
    private JButton btnPlusMinusInArithmetic;
    private JButton btnDoubleZeroInArithmetic;

    // Create button for Trigonometry panel
    private JButton btn00;
    private JButton btn0;
    private JButton btn1;
    private JButton btn2;
    private JButton btn3;
    private JButton btn4;
    private JButton btn5;
    private JButton btn6;
    private JButton btn7;
    private JButton btn8;
    private JButton btn9;
    private JButton btnEqualSymbol;
    private JButton btnDivisionSymbol;
    private JButton btnAdditionSymbol;
    private JButton btnSubtractionSymbol;
    private JButton btnModuloSymbol;
    private JButton btnClear;
    private JButton btnBackspace;
    private JButton btnMultiplySymbol;
    private JButton btnDotSymbol;
    private JButton btnOneOverX;
    private JButton btnX2;
    private JButton btnRadicalX2;
    private JButton btnSin;
    private JButton btnCos;
    private JButton btnCot;
    private JButton btnTan;
    private JButton btnPlusMinus;

    // Create button in bitwise panel
    private JButton btnDoubleZeroInBitwise;
    private JButton btnZeroInBitwise;
    private JButton btnOneInBitwise;
    private JButton btnTwoInBitwise;
    private JButton btnThreeInBitwise;
    private JButton btnFourInBitwise;
    private JButton btnFiveInBitwise;
    private JButton btnSixInBitwise;
    private JButton btnSevenInBitwise;
    private JButton btnEightInBitwise;
    private JButton btnNineInBitwise;
    private JButton btnEqualInBitwise;
    private JButton btnBackspaceInBitwise;
    private JButton btnClearInBitwise;
    private JButton btnAndInBitwise;
    private JButton btnPlusMinusInBitwise;
    private JButton btnOrInBitwise;
    private JButton btnXorInBitwise;
    private JButton btnLeftShiftInBitwise;
    private JButton btnRightShiftInBitwise;
    private JButton btnInversionInBitwise;

    // Create button for binaryArithmetic panel
    private JButton btnOneInBinaryArithmetic;
    private JButton btnZeroInBinaryArithmetic;
    private JButton btnPlusInBinaryArithmetic;
    private JButton btnMinusInBinaryArithmetic;
    private JButton btnDivisionInBinaryArithmetic;
    private JButton btnMultiplyInBinaryArithmetic;
    private JButton btnClearInBinaryArithmetic;
    private JButton btnBackspaceInBinaryArithmetic;
    private JButton btnEqualInBinaryArithmetic;

    // Create button for Money_Exchange panel

    private JButton btnDoubleZeroInMoneyExchange;
    private JButton btnZeroInMoneyExchange;
    private JButton btnOneInMoneyExchange;
    private JButton btnTwoInMoneyExchange;
    private JButton btnThreeInMoneyExchange;
    private JButton btnFourInMoneyExchange;
    private JButton btnFiveInMoneyExchange;
    private JButton btnSixInMoneyExchange;
    private JButton btnSevenInMoneyExchange;
    private JButton btnEightInMoneyExchange;
    private JButton btnNineInMoneyExchange;
    private JButton btnDotInMoneyExchange;
    private JButton btnClearInMoneyExchange;
    private JButton btnBackspaceInMoneyExchange;
    private JButton btnEqualInMoneyExchange;
    private JButton btnR2DInMoneyExchange;      // R2D = Riel to Dollar
    private JButton btnR2EInMoneyExchange;      // R2E = Riel to Euro
    private JButton btnR2FInMoneyExchange;      // R2F = Riel to Franc
    private JButton btnR2PInMoneyExchange;      // R2P = Riel to Pound
    private JButton btnR2BInMoneyExchange;      // R2B = Riel to Baht
    private JButton btnD2RInMoneyExchange;
    private JButton btnE2RInMoneyExchange;
    private JButton btnF2RInMoneyExchange;
    private JButton btnP2RInMoneyExchange;
    private JButton btnB2RInMoneyExchange;

    // Create button for Number_System_Conversion panel
    private JButton btnDoubleZeroInNumberSystemConversion;
    private JButton btnZeroInNumberSystemConversion;
    private JButton btnOneInNumberSystemConversion;
    private JButton btnTwoInNumberSystemConversion;
    private JButton btnThreeInNumberSystemConversion;
    private JButton btnFourInNumberSystemConversion;
    private JButton btnFiveInNumberSystemConversion;
    private JButton btnSixInNumberSystemConversion;
    private JButton btnSevenInNumberSystemConversion;
    private JButton btnEightInNumberSystemConversion;
    private JButton btnNineInNumberSystemConversion;

    private JButton btnA;
    private JButton btnB;
    private JButton btnC;
    private JButton btnD;
    private JButton btnE;
    private JButton btnF;

    private JButton btnClearInNumberSystemConversion;
    private JButton btnBackspaceInNumberSystemConversion;

    private JButton btnBin2Dec;
    private JButton btnBin2Oct;
    private JButton btnBin2Hex;

    private JButton btnOct2Dec;
    private JButton btnOct2Bin;
    private JButton btnOct2Hex;

    private JButton btnDec2Bin;
    private JButton btnDec2Oct;
    private JButton btnDec2Hex;

    private JButton btnHex2Dec;          // Hex2Dec = Hexadecimal to Decimal
    private JButton btnHex2Oct;
    private JButton btnHex2Bin;

    // Create Combobox to store Menu Item
    private JComboBox comboBox;

    // Create Text field
    private JTextField txtResult;

    // Create variable to stored firstNumber, secondNumber and Result as float
    private double num1 = 0;
    private double num2 = 0;
    private double result=0;

    private String Operator;
    // Create variable to stored firstNumber, secondNumber and Result as int to use in bitwise operator
    private int numA = 0;
    private int numB = 0;
    private int answer = 0;

    private String stringAnswers = "";
    private String stringOctal = "";


    private void createArithmeticCard(){

        // Create Main panel
        MainCard = new JPanel(new GridBagLayout());
        String[] menu = {"Arithmetic", "Trigonometry"};
        comboBox = new JComboBox(menu);
        comboBox.addActionListener(this);

        GridBagConstraints gbc = new GridBagConstraints();

        // Create a button and store it in the variable reference
        btnZeroInArithmetic = new JButton("0");
        btnZeroInArithmetic.setFont(new Font("Arial", Font.BOLD,14));
        btnZeroInArithmetic.setBackground(Color.CYAN);
        btnZeroInArithmetic.addActionListener(this);
        btnOneInArithmetic = new JButton("1");
        btnOneInArithmetic.setFont(new Font("Arial", Font.BOLD,14));
        btnOneInArithmetic.setBackground(Color.LIGHT_GRAY);
        btnOneInArithmetic.addActionListener(this);
        btnTwoInArithmetic = new JButton("2");
        btnTwoInArithmetic.setFont(new Font("Arial", Font.BOLD,14));
        btnTwoInArithmetic.setBackground(Color.LIGHT_GRAY);
        btnTwoInArithmetic.addActionListener(this);
        btnThreeInArithmetic = new JButton("3");
        btnThreeInArithmetic.setFont(new Font("Arial", Font.BOLD,14));
        btnThreeInArithmetic.setBackground(Color.LIGHT_GRAY);
        btnThreeInArithmetic.addActionListener(this);
        btnFourInArithmetic = new JButton("4");
        btnFourInArithmetic.setFont(new Font("Arial", Font.BOLD,14));
        btnFourInArithmetic.setBackground(Color.LIGHT_GRAY);
        btnFourInArithmetic.addActionListener(this);
        btnFiveInArithmetic = new JButton("5");
        btnFiveInArithmetic.setFont(new Font("Arial", Font.BOLD,14));
        btnFiveInArithmetic.setBackground(Color.LIGHT_GRAY);
        btnFiveInArithmetic.addActionListener(this);
        btnSixInArithmetic = new JButton("6");
        btnSixInArithmetic.setFont(new Font("Arial", Font.BOLD,14));
        btnSixInArithmetic.setBackground(Color.LIGHT_GRAY);
        btnSixInArithmetic.addActionListener(this);
        btnSevenInArithmetic = new JButton("7");
        btnSevenInArithmetic.setFont(new Font("Arial", Font.BOLD,14));
        btnSevenInArithmetic.setBackground(Color.LIGHT_GRAY);
        btnSevenInArithmetic.addActionListener(this);
        btnEightInArithmetic = new JButton("8");
        btnEightInArithmetic.setFont(new Font("Arial", Font.BOLD,14));
        btnEightInArithmetic.setBackground(Color.LIGHT_GRAY);
        btnEightInArithmetic.addActionListener(this);
        btnNineInArithmetic = new JButton("9");
        btnNineInArithmetic.setFont(new Font("Arial", Font.BOLD,14));
        btnNineInArithmetic.setBackground(Color.LIGHT_GRAY);
        btnNineInArithmetic.addActionListener(this);
        btnModuloInArithmetic = new JButton("%");
        btnModuloInArithmetic.setFont(new Font("Arial", Font.BOLD,14));
        btnModuloInArithmetic.setBackground(Color.CYAN);
        btnModuloInArithmetic.addActionListener(this);
        btnClearInArithmetic = new JButton("C");
        btnClearInArithmetic.setFont(new Font("Arial", Font.BOLD,14));
        btnClearInArithmetic.setBackground(Color.CYAN);
        btnClearInArithmetic.addActionListener(this);
        btnBackspaceInArithmetic = new JButton("<-");
        btnBackspaceInArithmetic.setFont(new Font("Arial", Font.BOLD,14));
        btnBackspaceInArithmetic.setBackground(Color.CYAN);
        btnBackspaceInArithmetic.addActionListener(this);
        btnMultiplyInArithmetic = new JButton("*");
        btnMultiplyInArithmetic.setFont(new Font("Arial", Font.BOLD,14));
        btnMultiplyInArithmetic.setBackground(Color.CYAN);
        btnMultiplyInArithmetic.addActionListener(this);
        btnDotInArithmetic = new JButton(".");
        btnDotInArithmetic.setFont(new Font("Arial", Font.BOLD,14));
        btnDotInArithmetic.setBackground(Color.CYAN);
        btnDotInArithmetic.addActionListener(this);
        btnAdditionInArithmetic = new JButton("+");
        btnAdditionInArithmetic.setFont(new Font("Arial", Font.BOLD,14));
        btnAdditionInArithmetic.setBackground(Color.CYAN);
        btnAdditionInArithmetic.addActionListener(this);
        btnSubtractionInArithmetic = new JButton("-");
        btnSubtractionInArithmetic.setFont(new Font("Arial", Font.BOLD,14));
        btnSubtractionInArithmetic.setBackground(Color.CYAN);
        btnSubtractionInArithmetic.addActionListener(this);
        btnDivisionInArithmetic = new JButton("/");
        btnDivisionInArithmetic.setFont(new Font("Arial", Font.BOLD,14));
        btnDivisionInArithmetic.setBackground(Color.CYAN);
        btnDivisionInArithmetic.addActionListener(this);
        btnEqualInArithmetic = new JButton("=");
        btnEqualInArithmetic.setFont(new Font("Arial", Font.BOLD,14));
        btnEqualInArithmetic.setBackground(Color.CYAN);
        btnEqualInArithmetic.addActionListener(this);
        btnOneOverXInArithmetic = new JButton("1/x");
        btnOneOverXInArithmetic.setFont(new Font("Arial", Font.BOLD, 14));
        btnOneOverXInArithmetic.setBackground(Color.CYAN);
        btnOneOverXInArithmetic.addActionListener(this);
        btnX2InArithmetic = new JButton("x^2");
        btnX2InArithmetic.setFont(new Font("Arial", Font.BOLD, 14));
        btnX2InArithmetic.setBackground(Color.CYAN);
        btnX2InArithmetic.addActionListener(this);
        btnRadicalX2InArithmetic = new JButton("2√(x)");
        btnRadicalX2InArithmetic.setFont(new Font("Arial",Font.BOLD,14));
        btnRadicalX2InArithmetic.setBackground(Color.CYAN);
        btnRadicalX2InArithmetic.addActionListener(this);
        btnPlusMinusInArithmetic = new JButton("+/-");
        btnPlusMinusInArithmetic.setFont(new Font("Arial",Font.BOLD,14));
        btnPlusMinusInArithmetic.setBackground(Color.CYAN);
        btnPlusMinusInArithmetic.addActionListener(this);
        btnDoubleZeroInArithmetic = new JButton("00");
        btnDoubleZeroInArithmetic.setFont(new Font("Arial",Font.BOLD,14));
        btnDoubleZeroInArithmetic.setBackground(Color.CYAN);
        btnDoubleZeroInArithmetic.addActionListener(this);

        // Create a text field that store it in the txtResult reference
        txtResult = new JTextField();
        txtResult.setPreferredSize(new Dimension(120,80));
        txtResult.setBackground(Color.LIGHT_GRAY);
        txtResult.setFont(new Font("Arial",Font.BOLD,20));

        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.weightx = 1;
        gbc.ipady = 20;
        gbc.gridx = 3;
        gbc.gridy = 1;
        MainCard.add(btnPlusMinusInArithmetic, gbc);

        // Add btn1
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 0;
        gbc.gridy = 5;
        MainCard.add(btnOneInArithmetic, gbc);

        // Add btnDivisionSymbol
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 3;
        gbc.gridy = 2;
        MainCard.add(btnDivisionInArithmetic, gbc);

        // Add btnOneOverX
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 0;
        gbc.gridy = 1;
        MainCard.add(btnOneOverXInArithmetic, gbc);

        // Add btnX2
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 1;
        gbc.gridy = 1;
        MainCard.add(btnX2InArithmetic,gbc);

        // Add btnRadicalX2
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 2;
        gbc.gridy = 1;
        MainCard.add(btnRadicalX2InArithmetic, gbc);

        // Add btnClear
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 0;
        gbc.gridy = 2;
        MainCard.add(btnClearInArithmetic, gbc);

        // Add btnModuloSymbol
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 1;
        gbc.gridy = 2;
        MainCard.add(btnModuloInArithmetic, gbc);

        // Add btnBackspace
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 2;
        gbc.gridy = 2;
        MainCard.add(btnBackspaceInArithmetic, gbc);

        // Add btn7
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 0;
        gbc.gridy = 3;
        MainCard.add(btnSevenInArithmetic, gbc);

        // Add btn8
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 1;
        gbc.gridy = 3;
        MainCard.add(btnEightInArithmetic, gbc);

        //Add btn9
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 2;
        gbc.gridy = 3;
        MainCard.add(btnNineInArithmetic, gbc);

        // Add btnSubtraction
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 3;
        gbc.gridy = 3;
        MainCard.add(btnSubtractionInArithmetic, gbc);

        // Add btn5
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 1;
        gbc.gridy = 4;
        MainCard.add(btnFiveInArithmetic, gbc);

        // Add btn4
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 0;
        gbc.gridy = 4;
        MainCard.add(btnFourInArithmetic, gbc);

        // Add btn6
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 2;
        gbc.gridy = 4;
        MainCard.add(btnSixInArithmetic, gbc);

        // Add btnAddition
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 3;
        gbc.gridy = 4;
        MainCard.add(btnAdditionInArithmetic, gbc);

        // Add btn2
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 1;
        gbc.gridy = 5;
        MainCard.add(btnTwoInArithmetic, gbc);

        // Add btn3
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 2;
        gbc.gridy = 5;
        MainCard.add(btnThreeInArithmetic, gbc);

        // Add btnMultiplySymbol
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 3;
        gbc.gridy = 5;
        MainCard.add(btnMultiplyInArithmetic, gbc);

        // Add btn0
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 0;
        gbc.gridy = 6;
        MainCard.add(btnZeroInArithmetic, gbc);

        // Add btn00
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 1;
        gbc.gridy = 6;
        MainCard.add(btnDoubleZeroInArithmetic, gbc);

        // Add btnDotSymbol
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 2;
        gbc.gridy = 6;
        MainCard.add(btnDotInArithmetic, gbc);

        // Add btnEqualSymbol
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 3;
        gbc.gridy = 6;
        MainCard.add(btnEqualInArithmetic, gbc);

    }
    private void createTrigonometryCard(){

        // Create Main panel
        SubCard = new JPanel(new GridBagLayout());
        String[] menu = {"Arithmetic", "Trigonometry"};
        comboBox = new JComboBox(menu);
        comboBox.addActionListener(this);

        GridBagConstraints gbc = new GridBagConstraints();

        // Create a button and store it in the variable reference
        btn0 = new JButton("0");
        btn0.setFont(new Font("Arial", Font.BOLD,14));
        btn0.setBackground(Color.LIGHT_GRAY);
        btn0.addActionListener(this);
        btn1 = new JButton("1");
        btn1.setFont(new Font("Arial", Font.BOLD,14));
        btn1.setBackground(Color.LIGHT_GRAY);
        btn1.addActionListener(this);
        btn2 = new JButton("2");
        btn2.setFont(new Font("Arial", Font.BOLD,14));
        btn2.setBackground(Color.LIGHT_GRAY);
        btn2.addActionListener(this);
        btn3 = new JButton("3");
        btn3.setFont(new Font("Arial", Font.BOLD,14));
        btn3.setBackground(Color.LIGHT_GRAY);
        btn3.addActionListener(this);
        btn4 = new JButton("4");
        btn4.setFont(new Font("Arial", Font.BOLD,14));
        btn4.setBackground(Color.LIGHT_GRAY);
        btn4.addActionListener(this);
        btn5 = new JButton("5");
        btn5.setFont(new Font("Arial", Font.BOLD,14));
        btn5.setBackground(Color.LIGHT_GRAY);
        btn5.addActionListener(this);
        btn6 = new JButton("6");
        btn6.setFont(new Font("Arial", Font.BOLD,14));
        btn6.setBackground(Color.LIGHT_GRAY);
        btn6.addActionListener(this);
        btn7 = new JButton("7");
        btn7.setFont(new Font("Arial", Font.BOLD,14));
        btn7.setBackground(Color.LIGHT_GRAY);
        btn7.addActionListener(this);
        btn8 = new JButton("8");
        btn8.setFont(new Font("Arial", Font.BOLD,14));
        btn8.setBackground(Color.LIGHT_GRAY);
        btn8.addActionListener(this);
        btn9 = new JButton("9");
        btn9.setFont(new Font("Arial", Font.BOLD,14));
        btn9.setBackground(Color.LIGHT_GRAY);
        btn9.addActionListener(this);
        btn00 = new JButton("00");
        btn00.setFont(new Font("Arial", Font.BOLD,14));
        btn00.setBackground(Color.LIGHT_GRAY);
        btn00.addActionListener(this);
        btnModuloSymbol = new JButton("%");
        btnModuloSymbol.setFont(new Font("Arial", Font.BOLD,14));
        btnModuloSymbol.setBackground(Color.CYAN);
        btnModuloSymbol.addActionListener(this);
        btnClear = new JButton("C");
        btnClear.setFont(new Font("Arial", Font.BOLD,14));
        btnClear.setBackground(Color.CYAN);
        btnClear.addActionListener(this);
        btnBackspace = new JButton("<-");
        btnBackspace.setFont(new Font("Arial", Font.BOLD,14));
        btnBackspace.setBackground(Color.CYAN);
        btnBackspace.addActionListener(this);
        btnMultiplySymbol = new JButton("*");
        btnMultiplySymbol.setFont(new Font("Arial", Font.BOLD,14));
        btnMultiplySymbol.setBackground(Color.CYAN);
        btnMultiplySymbol.addActionListener(this);
        btnDotSymbol = new JButton(".");
        btnDotSymbol.setFont(new Font("Arial", Font.BOLD,14));
        btnDotSymbol.setBackground(Color.CYAN);
        btnDotSymbol.addActionListener(this);
        btnAdditionSymbol = new JButton("+");
        btnAdditionSymbol.setFont(new Font("Arial", Font.BOLD,14));
        btnAdditionSymbol.setBackground(Color.CYAN);
        btnAdditionSymbol.addActionListener(this);
        btnSubtractionSymbol = new JButton("-");
        btnSubtractionSymbol.setFont(new Font("Arial", Font.BOLD,14));
        btnSubtractionSymbol.setBackground(Color.CYAN);
        btnSubtractionSymbol.addActionListener(this);
        btnDivisionSymbol = new JButton("/");
        btnDivisionSymbol.setFont(new Font("Arial", Font.BOLD,14));
        btnDivisionSymbol.setBackground(Color.CYAN);
        btnDivisionSymbol.addActionListener(this);
        btnEqualSymbol = new JButton("=");
        btnEqualSymbol.setFont(new Font("Arial", Font.BOLD,14));
        btnEqualSymbol.setBackground(Color.CYAN);
        btnEqualSymbol.addActionListener(this);
        btnOneOverX = new JButton("1/x");
        btnOneOverX.setFont(new Font("Arial", Font.BOLD, 14));
        btnOneOverX.setBackground(Color.CYAN);
        btnOneOverX.addActionListener(this);
        btnX2 = new JButton("x^2");
        btnX2.setFont(new Font("Arial", Font.BOLD, 14));
        btnX2.setBackground(Color.CYAN);
        btnX2.addActionListener(this);
        btnRadicalX2 = new JButton("2√(x)");
        btnRadicalX2.setFont(new Font("Arial",Font.BOLD,14));
        btnRadicalX2.setBackground(Color.CYAN);
        btnRadicalX2.addActionListener(this);
        btnCos = new JButton("cos");
        btnCos.setFont(new Font("Arial",Font.BOLD,14));
        btnCos.setBackground(Color.CYAN);
        btnCos.addActionListener(this);
        btnSin = new JButton("sin");
        btnSin.setFont(new Font("Arial",Font.BOLD,14));
        btnSin.setBackground(Color.CYAN);
        btnSin.addActionListener(this);
        btnCot = new JButton("cot");
        btnCot.setFont(new Font("Arial",Font.BOLD,14));
        btnCot.setBackground(Color.CYAN);
        btnCot.addActionListener(this);
        btnTan = new JButton("tan");
        btnTan.setFont(new Font("Arial",Font.BOLD,14));
        btnTan.setBackground(Color.CYAN);
        btnTan.addActionListener(this);
        btnPlusMinus = new JButton("+/-");
        btnPlusMinus.setFont(new Font("Arial",Font.BOLD,14));
        btnPlusMinus.setBackground(Color.CYAN);
        btnPlusMinus.addActionListener(this);

        // Create a text field that store it in the txtResult reference
        txtResult = new JTextField();
        txtResult.setPreferredSize(new Dimension(120,80));
        txtResult.setBackground(Color.LIGHT_GRAY);
        txtResult.setFont(new Font("Arial",Font.BOLD,20));
        txtResult.setHorizontalAlignment(JTextField.RIGHT);

        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.weightx = 1;
        gbc.ipady = 20;
        gbc.gridx = 0;
        gbc.gridy = 0;
        SubCard.add(btnPlusMinus, gbc);

        // Add btnPlusMinus
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.weightx = 1;
        gbc.ipady = 20;
        gbc.gridx = 1;
        gbc.gridy = 0;
        SubCard.add(btnCos, gbc);

        // Add btnCos
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.weightx = 1;
        gbc.ipady = 20;
        gbc.gridx = 1;
        gbc.gridy = 0;
        SubCard.add(btnCos, gbc);

        // Add btn1
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 0;
        gbc.gridy = 5;
        SubCard.add(btn1, gbc);

        // Add btnDivisionSymbol
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 3;
        gbc.gridy = 2;
        SubCard.add(btnDivisionSymbol, gbc);

        // Add btnSin
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 2;
        gbc.gridy = 0;
        SubCard.add(btnSin, gbc);

        // Add btnOneOverX
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 0;
        gbc.gridy = 1;
        SubCard.add(btnOneOverX, gbc);

        // Add btnX2
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 1;
        gbc.gridy = 1;
        SubCard.add(btnX2,gbc);

        // Add btnRadicalX2
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 2;
        gbc.gridy = 1;
        SubCard.add(btnRadicalX2, gbc);

        // Add btnCot
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 3;
        gbc.gridy = 0;
        SubCard.add(btnCot, gbc);

        // Add btnClear
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 0;
        gbc.gridy = 2;
        SubCard.add(btnClear, gbc);

        // Add btnModuloSymbol
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 1;
        gbc.gridy = 2;
        SubCard.add(btnModuloSymbol, gbc);

        // Add btnBackspace
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 2;
        gbc.gridy = 2;
        SubCard.add(btnBackspace, gbc);

        // Add btnTan
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 3;
        gbc.gridy = 1;
        SubCard.add(btnTan, gbc);

        // Add btn7
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 0;
        gbc.gridy = 3;
        SubCard.add(btn7, gbc);

        // Add btn8
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 1;
        gbc.gridy = 3;
        SubCard.add(btn8, gbc);

        //Add btn9
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 2;
        gbc.gridy = 3;
        SubCard.add(btn9, gbc);

        // Add btnSubtraction
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 3;
        gbc.gridy = 3;
        SubCard.add(btnSubtractionSymbol, gbc);

        // Add btn5
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 1;
        gbc.gridy = 4;
        SubCard.add(btn5, gbc);

        // Add btn4
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 0;
        gbc.gridy = 4;
        SubCard.add(btn4, gbc);

        // Add btn6
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 2;
        gbc.gridy = 4;
        SubCard.add(btn6, gbc);

        // Add btnAddition
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 3;
        gbc.gridy = 4;
        SubCard.add(btnAdditionSymbol, gbc);

        // Add btn2
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 1;
        gbc.gridy = 5;
        SubCard.add(btn2, gbc);

        // Add btn3
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 2;
        gbc.gridy = 5;
        SubCard.add(btn3, gbc);

        // Add btnMultiplySymbol
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 3;
        gbc.gridy = 5;
        SubCard.add(btnMultiplySymbol, gbc);

        // Add btn0
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 0;
        gbc.gridy = 6;
        SubCard.add(btn0, gbc);

        // Add btn00
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 1;
        gbc.gridy = 6;
        SubCard.add(btn00, gbc);

        // Add btnDotSymbol
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 2;
        gbc.gridy = 6;
        SubCard.add(btnDotSymbol, gbc);

        // Add btnEqualSymbol
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 3;
        gbc.gridy = 6;
        SubCard.add(btnEqualSymbol, gbc);

    }
    private void createBitwiseCard(){

        // Create Sub panel
        SubCard1 = new JPanel(new GridBagLayout());
        String[] menu = {"Arithmetic", "Trigonometry", "Bitwise"};
        comboBox = new JComboBox(menu);
        comboBox.addActionListener(this);

        GridBagConstraints gbc = new GridBagConstraints();

        // Create a button and store it in the variable reference
        btnDoubleZeroInBitwise = new JButton("00");
        btnDoubleZeroInBitwise.setFont(new Font("Arial", Font.BOLD,14));
        btnDoubleZeroInBitwise.setBackground(Color.LIGHT_GRAY);
        btnDoubleZeroInBitwise.addActionListener(this);
        btnZeroInBitwise = new JButton("0");
        btnZeroInBitwise.setFont(new Font("Arial", Font.BOLD,14));
        btnZeroInBitwise.setBackground(Color.LIGHT_GRAY);
        btnZeroInBitwise.addActionListener(this);
        btnOneInBitwise = new JButton("1");
        btnOneInBitwise.setFont(new Font("Arial", Font.BOLD,14));
        btnOneInBitwise.setBackground(Color.LIGHT_GRAY);
        btnOneInBitwise.addActionListener(this);
        btnTwoInBitwise = new JButton("2");
        btnTwoInBitwise.setFont(new Font("Arial", Font.BOLD,14));
        btnTwoInBitwise.setBackground(Color.LIGHT_GRAY);
        btnTwoInBitwise.addActionListener(this);
        btnThreeInBitwise = new JButton("3");
        btnThreeInBitwise.setFont(new Font("Arial", Font.BOLD,14));
        btnThreeInBitwise.setBackground(Color.LIGHT_GRAY);
        btnThreeInBitwise.addActionListener(this);
        btnFourInBitwise = new JButton("4");
        btnFourInBitwise.setFont(new Font("Arial", Font.BOLD,14));
        btnFourInBitwise.setBackground(Color.LIGHT_GRAY);
        btnFourInBitwise.addActionListener(this);
        btnFiveInBitwise = new JButton("5");
        btnFiveInBitwise.setFont(new Font("Arial", Font.BOLD,14));
        btnFiveInBitwise.setBackground(Color.LIGHT_GRAY);
        btnFiveInBitwise.addActionListener(this);
        btnSixInBitwise = new JButton("6");
        btnSixInBitwise.setFont(new Font("Arial", Font.BOLD,14));
        btnSixInBitwise.setBackground(Color.LIGHT_GRAY);
        btnSixInBitwise.addActionListener(this);
        btnSevenInBitwise = new JButton("7");
        btnSevenInBitwise.setFont(new Font("Arial", Font.BOLD,14));
        btnSevenInBitwise.setBackground(Color.LIGHT_GRAY);
        btnSevenInBitwise.addActionListener(this);
        btnEightInBitwise = new JButton("8");
        btnEightInBitwise.setFont(new Font("Arial", Font.BOLD,14));
        btnEightInBitwise.setBackground(Color.LIGHT_GRAY);
        btnEightInBitwise.addActionListener(this);
        btnNineInBitwise = new JButton("9");
        btnNineInBitwise.setFont(new Font("Arial", Font.BOLD,14));
        btnNineInBitwise.setBackground(Color.LIGHT_GRAY);
        btnNineInBitwise.addActionListener(this);
        btnClearInBitwise = new JButton("C");
        btnClearInBitwise.setFont(new Font("Arial", Font.BOLD,14));
        btnClearInBitwise.setBackground(Color.CYAN);
        btnClearInBitwise.addActionListener(this);
        btnBackspaceInBitwise = new JButton("<-");
        btnBackspaceInBitwise.setFont(new Font("Arial", Font.BOLD,14));
        btnBackspaceInBitwise.setBackground(Color.CYAN);
        btnBackspaceInBitwise.addActionListener(this);
        btnEqualInBitwise = new JButton("=");
        btnEqualInBitwise.setFont(new Font("Arial", Font.BOLD,14));
        btnEqualInBitwise.setBackground(Color.CYAN);
        btnEqualInBitwise.addActionListener(this);
        btnPlusMinusInBitwise = new JButton("+/-");
        btnPlusMinusInBitwise.setFont(new Font("Arial",Font.BOLD,14));
        btnPlusMinusInBitwise.setBackground(Color.CYAN);
        btnPlusMinusInBitwise.addActionListener(this);
        btnAndInBitwise = new JButton("AND");
        btnAndInBitwise.setFont(new Font("Arial",Font.BOLD,14));
        btnAndInBitwise.setBackground(Color.CYAN);
        btnAndInBitwise.addActionListener(this);
        btnOrInBitwise = new JButton("OR");
        btnOrInBitwise.setFont(new Font("Arial",Font.BOLD,14));
        btnOrInBitwise.setBackground(Color.CYAN);
        btnOrInBitwise.addActionListener(this);
        btnXorInBitwise = new JButton("XOR");
        btnXorInBitwise.setFont(new Font("Arial",Font.BOLD,14));
        btnXorInBitwise.setBackground(Color.CYAN);
        btnXorInBitwise.addActionListener(this);
        btnLeftShiftInBitwise = new JButton("<<");
        btnLeftShiftInBitwise.setFont(new Font("Arial",Font.BOLD,14));
        btnLeftShiftInBitwise.setBackground(Color.CYAN);
        btnLeftShiftInBitwise.addActionListener(this);
        btnRightShiftInBitwise = new JButton(">>");
        btnRightShiftInBitwise.setFont(new Font("Arial",Font.BOLD,14));
        btnRightShiftInBitwise.setBackground(Color.CYAN);
        btnRightShiftInBitwise.addActionListener(this);
        btnInversionInBitwise = new JButton("~");
        btnInversionInBitwise.setFont(new Font("Arial",Font.BOLD,14));
        btnInversionInBitwise.setBackground(Color.CYAN);
        btnInversionInBitwise.addActionListener(this);

        // Create a text field that store it in the txtResult reference
        txtResult = new JTextField();
        txtResult.setPreferredSize(new Dimension(120,80));
        txtResult.setBackground(Color.LIGHT_GRAY);
        txtResult.setFont(new Font("Arial",Font.BOLD,20));
        txtResult.setHorizontalAlignment(JTextField.RIGHT);

        // Add btnClear
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.weightx = 1;
        gbc.ipady = 20;
        gbc.gridx = 0;
        gbc.gridy = 0;
        SubCard1.add(btnClearInBitwise, gbc);

        // Add btnBackspace
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.weightx = 1;
        gbc.ipady = 20;
        gbc.gridx = 1;
        gbc.gridy = 0;
        SubCard1.add(btnBackspaceInBitwise, gbc);

        // Add btnInversion
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 2;
        gbc.gridy = 0;
        SubCard1.add(btnInversionInBitwise, gbc);

        // Add btnAnd
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 3;
        gbc.gridy = 0;
        SubCard1.add(btnAndInBitwise, gbc);

        // Add btn7
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 0;
        gbc.gridy = 1;
        SubCard1.add(btnSevenInBitwise, gbc);

        // Add btn8
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 1;
        gbc.gridy = 1;
        SubCard1.add(btnEightInBitwise,gbc);

        // Add btn9
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 2;
        gbc.gridy = 1;
        SubCard1.add(btnNineInBitwise, gbc);

        // Add btnOr
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 3;
        gbc.gridy = 1;
        SubCard1.add(btnOrInBitwise, gbc);

        // Add btn4
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 0;
        gbc.gridy = 2;
        SubCard1.add(btnFourInBitwise, gbc);

        // Add btn5
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 1;
        gbc.gridy = 2;
        SubCard1.add(btnFiveInBitwise, gbc);

        // Add btn6
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 2;
        gbc.gridy = 2;
        SubCard1.add(btnSixInBitwise, gbc);

        // Add btnXor
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 3;
        gbc.gridy = 2;
        SubCard1.add(btnXorInBitwise, gbc);

        // Add btn1
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 0;
        gbc.gridy = 3;
        SubCard1.add(btnOneInBitwise, gbc);

        // Add btn2
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 1;
        gbc.gridy = 3;
        SubCard1.add(btnTwoInBitwise, gbc);

        //Add btn3
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 2;
        gbc.gridy = 3;
        SubCard1.add(btnThreeInBitwise, gbc);

        // Add btnLeftShift
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 3;
        gbc.gridy = 3;
        SubCard1.add(btnLeftShiftInBitwise, gbc);

        // Add btn0
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 0;
        gbc.gridy = 4;
        SubCard1.add(btnZeroInBitwise, gbc);

        // Add btnDot
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 1;
        gbc.gridy = 4;
        SubCard1.add(btnDoubleZeroInBitwise, gbc);

        // Add btnEqual
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 2;
        gbc.gridy = 4;
        SubCard1.add(btnEqualInBitwise, gbc);

        // Add btnRightShift
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 3;
        gbc.gridy = 4;
        SubCard1.add(btnRightShiftInBitwise, gbc);

    }
    private void createBinaryArithmeticCard(){

        // Create Sub panel
        SubCard2 = new JPanel(new GridBagLayout());
        String[] menu = {"Arithmetic", "Trigonometry", "Bitwise", "Binary_Arithmetic"};
        comboBox = new JComboBox(menu);
        comboBox.addActionListener(this);

        GridBagConstraints gbc = new GridBagConstraints();

        btnZeroInBinaryArithmetic = new JButton("0");
        btnZeroInBinaryArithmetic.setFont(new Font("Arial", Font.BOLD,20));
        btnZeroInBinaryArithmetic.setBackground(Color.LIGHT_GRAY);
        btnZeroInBinaryArithmetic.addActionListener(this);
        btnOneInBinaryArithmetic = new JButton("1");
        btnOneInBinaryArithmetic.setFont(new Font("Arial", Font.BOLD,20));
        btnOneInBinaryArithmetic.setBackground(Color.LIGHT_GRAY);
        btnOneInBinaryArithmetic.addActionListener(this);
        btnPlusInBinaryArithmetic = new JButton("+");
        btnPlusInBinaryArithmetic.setFont(new Font("Arial", Font.BOLD,20));
        btnPlusInBinaryArithmetic.setBackground(Color.CYAN);
        btnPlusInBinaryArithmetic.addActionListener(this);
        btnMinusInBinaryArithmetic = new JButton("-");
        btnMinusInBinaryArithmetic.setFont(new Font("Arial", Font.BOLD,20));
        btnMinusInBinaryArithmetic.setBackground(Color.CYAN);
        btnMinusInBinaryArithmetic.addActionListener(this);
        btnEqualInBinaryArithmetic = new JButton("=");
        btnEqualInBinaryArithmetic.setFont(new Font("Arial", Font.BOLD,20));
        btnEqualInBinaryArithmetic.setBackground(Color.CYAN);
        btnEqualInBinaryArithmetic.addActionListener(this);
        btnDivisionInBinaryArithmetic = new JButton("/");
        btnDivisionInBinaryArithmetic.setFont(new Font("Arial", Font.BOLD,20));
        btnDivisionInBinaryArithmetic.setBackground(Color.CYAN);
        btnDivisionInBinaryArithmetic.addActionListener(this);
        btnMultiplyInBinaryArithmetic = new JButton("x");
        btnMultiplyInBinaryArithmetic.setFont(new Font("Arial", Font.BOLD,20));
        btnMultiplyInBinaryArithmetic.setBackground(Color.CYAN);
        btnMultiplyInBinaryArithmetic.addActionListener(this);
        btnClearInBinaryArithmetic = new JButton("C");
        btnClearInBinaryArithmetic.setFont(new Font("Arial", Font.BOLD,20));
        btnClearInBinaryArithmetic.setBackground(Color.CYAN);
        btnClearInBinaryArithmetic.addActionListener(this);
        btnBackspaceInBinaryArithmetic = new JButton("<-");
        btnBackspaceInBinaryArithmetic.setFont(new Font("Arial", Font.BOLD,20));
        btnBackspaceInBinaryArithmetic.setBackground(Color.CYAN);
        btnBackspaceInBinaryArithmetic.addActionListener(this);

        // Add btnClearInBinaryArithmetic
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.weightx = 1;
        gbc.ipady = 20;
        gbc.gridx = 0;
        gbc.gridy = 0;
        SubCard2.add(btnClearInBinaryArithmetic, gbc);

        // Add btnDivisionInBinaryArithmetic
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.weightx = 1;
        gbc.ipady = 20;
        gbc.gridx = 1;
        gbc.gridy = 0;
        SubCard2.add(btnDivisionInBinaryArithmetic, gbc);

        // Add btnBackspaceInBinaryArithmetic
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 2;
        gbc.gridy = 0;
        SubCard2.add(btnBackspaceInBinaryArithmetic, gbc);

        // Add btnPlusInBinaryArithmetic
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 0;
        gbc.gridy = 1;
        SubCard2.add(btnPlusInBinaryArithmetic, gbc);

        // Add btnMinusInBinaryArithmetic
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 1;
        gbc.gridy = 1;
        SubCard2.add(btnMinusInBinaryArithmetic,gbc);

        // Add btnMultiplyInBinaryArithmetic
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 2;
        gbc.gridy = 1;
        SubCard2.add(btnMultiplyInBinaryArithmetic, gbc);

        // Add btnZeroInBinaryArithmetic
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 0;
        gbc.gridy = 2;
        SubCard2.add(btnZeroInBinaryArithmetic, gbc);

        // Add btnOneInBinaryArithmetic
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 1;
        gbc.gridy = 2;
        SubCard2.add(btnOneInBinaryArithmetic, gbc);

        // Add btnEqualInBinaryArithmetic
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 2;
        gbc.gridy = 2;
        SubCard2.add(btnEqualInBinaryArithmetic, gbc);

    }
    private void createMoneyExchangeCard(){
        // Create Sub panel
        SubCard3 = new JPanel(new GridBagLayout());
        String[] menu = {"Arithmetic", "Trigonometry", "Bitwise", "Binary_Arithmetic", "Money_Exchange"};
        comboBox = new JComboBox(menu);
        comboBox.addActionListener(this);

        GridBagConstraints gbc = new GridBagConstraints();

        btnDoubleZeroInMoneyExchange = new JButton("00");
        btnDoubleZeroInMoneyExchange.setFont(new Font("Arial", Font.BOLD,14));
        btnDoubleZeroInMoneyExchange.setBackground(Color.LIGHT_GRAY);
        btnDoubleZeroInMoneyExchange.addActionListener(this);
        btnZeroInMoneyExchange = new JButton("0");
        btnZeroInMoneyExchange.setFont(new Font("Arial", Font.BOLD,14));
        btnZeroInMoneyExchange.setBackground(Color.LIGHT_GRAY);
        btnZeroInMoneyExchange.addActionListener(this);
        btnOneInMoneyExchange = new JButton("1");
        btnOneInMoneyExchange.setFont(new Font("Arial", Font.BOLD,14));
        btnOneInMoneyExchange.setBackground(Color.LIGHT_GRAY);
        btnOneInMoneyExchange.addActionListener(this);
        btnTwoInMoneyExchange = new JButton("2");
        btnTwoInMoneyExchange.setFont(new Font("Arial", Font.BOLD,14));
        btnTwoInMoneyExchange.setBackground(Color.LIGHT_GRAY);
        btnTwoInMoneyExchange.addActionListener(this);
        btnThreeInMoneyExchange = new JButton("3");
        btnThreeInMoneyExchange.setFont(new Font("Arial", Font.BOLD,14));
        btnThreeInMoneyExchange.setBackground(Color.LIGHT_GRAY);
        btnThreeInMoneyExchange.addActionListener(this);
        btnFourInMoneyExchange = new JButton("4");
        btnFourInMoneyExchange.setFont(new Font("Arial", Font.BOLD,14));
        btnFourInMoneyExchange.setBackground(Color.LIGHT_GRAY);
        btnFourInMoneyExchange.addActionListener(this);
        btnFiveInMoneyExchange = new JButton("5");
        btnFiveInMoneyExchange.setFont(new Font("Arial", Font.BOLD,14));
        btnFiveInMoneyExchange.setBackground(Color.LIGHT_GRAY);
        btnFiveInMoneyExchange.addActionListener(this);
        btnSixInMoneyExchange= new JButton("6");
        btnSixInMoneyExchange.setFont(new Font("Arial", Font.BOLD,14));
        btnSixInMoneyExchange.setBackground(Color.LIGHT_GRAY);
        btnSixInMoneyExchange.addActionListener(this);
        btnSevenInMoneyExchange = new JButton("7");
        btnSevenInMoneyExchange.setFont(new Font("Arial", Font.BOLD,14));
        btnSevenInMoneyExchange.setBackground(Color.LIGHT_GRAY);
        btnSevenInMoneyExchange.addActionListener(this);
        btnEightInMoneyExchange = new JButton("8");
        btnEightInMoneyExchange.setFont(new Font("Arial", Font.BOLD,14));
        btnEightInMoneyExchange.setBackground(Color.LIGHT_GRAY);
        btnEightInMoneyExchange.addActionListener(this);
        btnNineInMoneyExchange = new JButton("9");
        btnNineInMoneyExchange.setFont(new Font("Arial", Font.BOLD,14));
        btnNineInMoneyExchange.setBackground(Color.LIGHT_GRAY);
        btnNineInMoneyExchange.addActionListener(this);

        btnClearInMoneyExchange = new JButton("C");
        btnClearInMoneyExchange.setFont(new Font("Arial", Font.BOLD,14));
        btnClearInMoneyExchange.setBackground(Color.CYAN);
        btnClearInMoneyExchange.addActionListener(this);
        btnBackspaceInMoneyExchange = new JButton("<-");
        btnBackspaceInMoneyExchange.setFont(new Font("Arial", Font.BOLD,14));
        btnBackspaceInMoneyExchange.setBackground(Color.CYAN);
        btnBackspaceInMoneyExchange.addActionListener(this);
        btnEqualInMoneyExchange = new JButton("=");
        btnEqualInMoneyExchange.setFont(new Font("Arial", Font.BOLD,14));
        btnEqualInMoneyExchange.setBackground(Color.CYAN);
        btnEqualInMoneyExchange.addActionListener(this);
        btnDotInMoneyExchange = new JButton(".");
        btnDotInMoneyExchange.setFont(new Font("Arial", Font.BOLD,14));
        btnDotInMoneyExchange.setBackground(Color.CYAN);
        btnDotInMoneyExchange.addActionListener(this);
        btnDotInMoneyExchange = new JButton(".");
        btnDotInMoneyExchange.setFont(new Font("Arial", Font.BOLD,14));
        btnDotInMoneyExchange.setBackground(Color.CYAN);
        btnDotInMoneyExchange.addActionListener(this);

        btnR2DInMoneyExchange = new JButton("R2D");
        btnR2DInMoneyExchange.setFont(new Font("Arial", Font.BOLD,14));
        btnR2DInMoneyExchange.setBackground(Color.CYAN);
        btnR2DInMoneyExchange.addActionListener(this);
        btnP2RInMoneyExchange = new JButton("P2R");
        btnP2RInMoneyExchange.setFont(new Font("Arial", Font.BOLD,14));
        btnP2RInMoneyExchange.setBackground(Color.CYAN);
        btnP2RInMoneyExchange.addActionListener(this);
        btnR2EInMoneyExchange = new JButton("R2E");
        btnR2EInMoneyExchange.setFont(new Font("Arial", Font.BOLD,14));
        btnR2EInMoneyExchange.setBackground(Color.CYAN);
        btnR2EInMoneyExchange.addActionListener(this);
        btnR2FInMoneyExchange = new JButton("R2F");
        btnR2FInMoneyExchange.setFont(new Font("Arial", Font.BOLD,14));
        btnR2FInMoneyExchange.setBackground(Color.CYAN);
        btnR2FInMoneyExchange.addActionListener(this);
        btnR2PInMoneyExchange = new JButton("R2P");
        btnR2PInMoneyExchange.setFont(new Font("Arial", Font.BOLD,14));
        btnR2PInMoneyExchange.setBackground(Color.CYAN);
        btnR2PInMoneyExchange.addActionListener(this);
        btnR2BInMoneyExchange = new JButton("R2B");
        btnR2BInMoneyExchange.setFont(new Font("Arial", Font.BOLD,14));
        btnR2BInMoneyExchange.setBackground(Color.CYAN);
        btnR2BInMoneyExchange.addActionListener(this);
        btnD2RInMoneyExchange = new JButton("D2R");
        btnD2RInMoneyExchange.setFont(new Font("Arial", Font.BOLD,14));
        btnD2RInMoneyExchange.setBackground(Color.CYAN);
        btnD2RInMoneyExchange.addActionListener(this);
        btnE2RInMoneyExchange= new JButton("E2R");
        btnE2RInMoneyExchange.setFont(new Font("Arial", Font.BOLD,14));
        btnE2RInMoneyExchange.setBackground(Color.CYAN);
        btnE2RInMoneyExchange.addActionListener(this);
        btnF2RInMoneyExchange = new JButton("F2R");
        btnF2RInMoneyExchange.setFont(new Font("Arial", Font.BOLD,14));
        btnF2RInMoneyExchange.setBackground(Color.CYAN);
        btnF2RInMoneyExchange.addActionListener(this);
        btnB2RInMoneyExchange = new JButton("B2R");
        btnB2RInMoneyExchange.setFont(new Font("Arial", Font.BOLD,14));
        btnB2RInMoneyExchange.setBackground(Color.CYAN);
        btnB2RInMoneyExchange.addActionListener(this);

        // Add btnClear
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.weightx = 1;
        gbc.ipady = 20;
        gbc.gridx = 0;
        gbc.gridy = 0;
        SubCard3.add(btnClearInMoneyExchange, gbc);

        // Add btnEqualInMoneyExchange
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.weightx = 1;
        gbc.ipady = 20;
        gbc.gridx = 1;
        gbc.gridy = 0;
        SubCard3.add(btnEqualInMoneyExchange, gbc);

        // Add btnbackspace_in_money_exchange
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 2;
        gbc.gridy = 0;
        SubCard3.add(btnBackspaceInMoneyExchange, gbc);

        // Add btnr2dInMoneyExchange
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 3;
        gbc.gridy = 0;
        SubCard3.add(btnR2DInMoneyExchange, gbc);

        // Add btnd2RInMoneyExchange
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 4;
        gbc.gridy = 0;
        SubCard3.add(btnD2RInMoneyExchange, gbc);

        // Add btn7
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 0;
        gbc.gridy = 1;
        SubCard3.add(btnSevenInMoneyExchange, gbc);

        // Add btn8
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 1;
        gbc.gridy = 1;
        SubCard3.add(btnEightInMoneyExchange,gbc);

        // Add btn9
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 2;
        gbc.gridy = 1;
        SubCard3.add(btnNineInMoneyExchange, gbc);

        // Add btnr2eInMoneyExchange
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 3;
        gbc.gridy = 1;
        SubCard3.add(btnR2EInMoneyExchange, gbc);

        // Add btnE2RInMoneyExchange
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 4;
        gbc.gridy = 1;
        SubCard3.add(btnE2RInMoneyExchange, gbc);

        // Add btn4
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 0;
        gbc.gridy = 2;
        SubCard3.add(btnFourInMoneyExchange, gbc);

        // Add btn5
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 1;
        gbc.gridy = 2;
        SubCard3.add(btnFiveInMoneyExchange, gbc);

        // Add btn6
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 2;
        gbc.gridy = 2;
        SubCard3.add(btnSixInMoneyExchange, gbc);

        // Add btnR2fInMoneyExchange
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 3;
        gbc.gridy = 2;
        SubCard3.add(btnR2FInMoneyExchange, gbc);

        // Add btnF2RInMoneyExchange
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 4;
        gbc.gridy = 2;
        SubCard3.add(btnF2RInMoneyExchange, gbc);

        // Add btn1
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 0;
        gbc.gridy = 3;
        SubCard3.add(btnOneInMoneyExchange, gbc);

        // Add btn2
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 1;
        gbc.gridy = 3;
        SubCard3.add(btnTwoInMoneyExchange, gbc);

        //Add btn3
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 2;
        gbc.gridy = 3;
        SubCard3.add(btnThreeInMoneyExchange, gbc);

        // Add btnR2pInMoneyExchange
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 3;
        gbc.gridy = 3;
        SubCard3.add(btnR2PInMoneyExchange, gbc);

        // Add btnP2RInMoneyExchange
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 4;
        gbc.gridy = 3;
        SubCard3.add(btnP2RInMoneyExchange, gbc);

        // Add btn00
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 0;
        gbc.gridy = 4;
        SubCard3.add(btnDoubleZeroInMoneyExchange, gbc);

        // Add btn0
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 1;
        gbc.gridy = 4;
        SubCard3.add(btnZeroInMoneyExchange, gbc);

        // Add btnDot
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 2;
        gbc.gridy = 4;
        SubCard3.add(btnDotInMoneyExchange, gbc);

        // Add btnR2BInMoneyExchange
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 3;
        gbc.gridy = 4;
        SubCard3.add(btnR2BInMoneyExchange, gbc);

        // Add btnB2RInMoneyExchange
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 4;
        gbc.gridy = 4;
        SubCard3.add(btnB2RInMoneyExchange, gbc);


    }
    private void createNumberSystemConversionCard(){
        // Create Sub panel
        SubCard4 = new JPanel(new GridBagLayout());
        String[] menu = {"Arithmetic", "Trigonometry", "Bitwise", "Binary_Arithmetic", "Money_Exchange", "Number_System_Conversion"};
        comboBox = new JComboBox(menu);
        comboBox.addActionListener(this);

        GridBagConstraints gbc = new GridBagConstraints();

        btnDoubleZeroInNumberSystemConversion = new JButton("00");
        btnDoubleZeroInNumberSystemConversion.setFont(new Font("Arial", Font.BOLD,14));
        btnDoubleZeroInNumberSystemConversion.setBackground(Color.LIGHT_GRAY);
        btnDoubleZeroInNumberSystemConversion.addActionListener(this);
        btnZeroInNumberSystemConversion = new JButton("0");
        btnZeroInNumberSystemConversion.setFont(new Font("Arial", Font.BOLD,14));
        btnZeroInNumberSystemConversion.setBackground(Color.LIGHT_GRAY);
        btnZeroInNumberSystemConversion.addActionListener(this);
        btnOneInNumberSystemConversion = new JButton("1");
        btnOneInNumberSystemConversion.setFont(new Font("Arial", Font.BOLD,14));
        btnOneInNumberSystemConversion.setBackground(Color.LIGHT_GRAY);
        btnOneInNumberSystemConversion.addActionListener(this);
        btnTwoInNumberSystemConversion = new JButton("2");
        btnTwoInNumberSystemConversion.setFont(new Font("Arial", Font.BOLD,14));
        btnTwoInNumberSystemConversion.setBackground(Color.LIGHT_GRAY);
        btnTwoInNumberSystemConversion.addActionListener(this);
        btnThreeInNumberSystemConversion = new JButton("3");
        btnThreeInNumberSystemConversion.setFont(new Font("Arial", Font.BOLD,14));
        btnThreeInNumberSystemConversion.setBackground(Color.LIGHT_GRAY);
        btnThreeInNumberSystemConversion.addActionListener(this);
        btnFourInNumberSystemConversion = new JButton("4");
        btnFourInNumberSystemConversion.setFont(new Font("Arial", Font.BOLD,14));
        btnFourInNumberSystemConversion.setBackground(Color.LIGHT_GRAY);
        btnFourInNumberSystemConversion.addActionListener(this);
        btnFiveInNumberSystemConversion = new JButton("5");
        btnFiveInNumberSystemConversion.setFont(new Font("Arial", Font.BOLD,14));
        btnFiveInNumberSystemConversion.setBackground(Color.LIGHT_GRAY);
        btnFiveInNumberSystemConversion.addActionListener(this);
        btnSixInNumberSystemConversion = new JButton("6");
        btnSixInNumberSystemConversion.setFont(new Font("Arial", Font.BOLD,14));
        btnSixInNumberSystemConversion.setBackground(Color.LIGHT_GRAY);
        btnSixInNumberSystemConversion.addActionListener(this);
        btnSevenInNumberSystemConversion = new JButton("7");
        btnSevenInNumberSystemConversion.setFont(new Font("Arial", Font.BOLD,14));
        btnSevenInNumberSystemConversion.setBackground(Color.LIGHT_GRAY);
        btnSevenInNumberSystemConversion.addActionListener(this);
        btnEightInNumberSystemConversion = new JButton("8");
        btnEightInNumberSystemConversion.setFont(new Font("Arial", Font.BOLD,14));
        btnEightInNumberSystemConversion.setBackground(Color.LIGHT_GRAY);
        btnEightInNumberSystemConversion.addActionListener(this);
        btnNineInNumberSystemConversion = new JButton("9");
        btnNineInNumberSystemConversion.setFont(new Font("Arial", Font.BOLD,14));
        btnNineInNumberSystemConversion.setBackground(Color.LIGHT_GRAY);
        btnNineInNumberSystemConversion.addActionListener(this);
        btnA = new JButton("A");
        btnA.setFont(new Font("Arial", Font.BOLD,14));
        btnA.setBackground(Color.LIGHT_GRAY);
        btnA.addActionListener(this);
        btnB = new JButton("B");
        btnB.setFont(new Font("Arial", Font.BOLD,14));
        btnB.setBackground(Color.LIGHT_GRAY);
        btnB.addActionListener(this);
        btnC = new JButton("C");
        btnC.setFont(new Font("Arial", Font.BOLD,14));
        btnC.setBackground(Color.LIGHT_GRAY);
        btnC.addActionListener(this);
        btnD = new JButton("D");
        btnD.setFont(new Font("Arial", Font.BOLD,14));
        btnD.setBackground(Color.LIGHT_GRAY);
        btnD.addActionListener(this);
        btnE = new JButton("E");
        btnE.setFont(new Font("Arial", Font.BOLD,14));
        btnE.setBackground(Color.LIGHT_GRAY);
        btnE.addActionListener(this);
        btnF = new JButton("F");
        btnF.setFont(new Font("Arial", Font.BOLD,14));
        btnF.setBackground(Color.LIGHT_GRAY);
        btnF.addActionListener(this);

        btnClearInNumberSystemConversion = new JButton("C");
        btnClearInNumberSystemConversion.setFont(new Font("Arial", Font.BOLD,14));
        btnClearInNumberSystemConversion.setBackground(Color.CYAN);
        btnClearInNumberSystemConversion.addActionListener(this);
        btnBackspaceInNumberSystemConversion = new JButton("<-");
        btnBackspaceInNumberSystemConversion.setFont(new Font("Arial", Font.BOLD,14));
        btnBackspaceInNumberSystemConversion.setBackground(Color.CYAN);
        btnBackspaceInNumberSystemConversion.addActionListener(this);

        btnBin2Dec = new JButton("B2D");
        btnBin2Dec.setFont(new Font("Arial", Font.BOLD,14));
        btnBin2Dec.setBackground(Color.CYAN);
        btnBin2Dec.addActionListener(this);
        btnBin2Oct = new JButton("B2O");
        btnBin2Oct.setFont(new Font("Arial", Font.BOLD,14));
        btnBin2Oct.setBackground(Color.CYAN);
        btnBin2Oct.addActionListener(this);
        btnBin2Hex = new JButton("B2H");
        btnBin2Hex.setFont(new Font("Arial", Font.BOLD,14));
        btnBin2Hex.setBackground(Color.CYAN);
        btnBin2Hex.addActionListener(this);

        btnOct2Bin = new JButton("O2B");
        btnOct2Bin.setFont(new Font("Arial", Font.BOLD,14));
        btnOct2Bin.setBackground(Color.CYAN);
        btnOct2Bin.addActionListener(this);
        btnOct2Dec = new JButton("O2D");
        btnOct2Dec.setFont(new Font("Arial", Font.BOLD,14));
        btnOct2Dec.setBackground(Color.CYAN);
        btnOct2Dec.addActionListener(this);
        btnOct2Hex = new JButton("O2H");
        btnOct2Hex.setFont(new Font("Arial", Font.BOLD,14));
        btnOct2Hex.setBackground(Color.CYAN);
        btnOct2Hex.addActionListener(this);

        btnDec2Bin = new JButton("D2B");
        btnDec2Bin.setFont(new Font("Arial", Font.BOLD,14));
        btnDec2Bin.setBackground(Color.CYAN);
        btnDec2Bin.addActionListener(this);
        btnDec2Oct = new JButton("D2O");
        btnDec2Oct.setFont(new Font("Arial", Font.BOLD,14));
        btnDec2Oct.setBackground(Color.CYAN);
        btnDec2Oct.addActionListener(this);
        btnDec2Hex = new JButton("D2H");
        btnDec2Hex.setFont(new Font("Arial", Font.BOLD,14));
        btnDec2Hex.setBackground(Color.CYAN);
        btnDec2Hex.addActionListener(this);

        btnHex2Bin = new JButton("H2B");
        btnHex2Bin.setFont(new Font("Arial", Font.BOLD,14));
        btnHex2Bin.setBackground(Color.CYAN);
        btnHex2Bin.addActionListener(this);
        btnHex2Oct = new JButton("H2O");
        btnHex2Oct.setFont(new Font("Arial", Font.BOLD,14));
        btnHex2Oct.setBackground(Color.CYAN);
        btnHex2Oct.addActionListener(this);
        btnHex2Dec = new JButton("H2D");
        btnHex2Dec.setFont(new Font("Arial", Font.BOLD,14));
        btnHex2Dec.setBackground(Color.CYAN);
        btnHex2Dec.addActionListener(this);

        // Add btnClear
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.weightx = 1;
        gbc.ipady = 20;
        gbc.gridx = 0;
        gbc.gridy = 0;
        SubCard4.add(btnClearInNumberSystemConversion, gbc);

        // Add btnbackspace
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.weightx = 1;
        gbc.ipady = 20;
        gbc.gridx = 1;
        gbc.gridy = 0;
        SubCard4.add(btnBackspaceInNumberSystemConversion, gbc);

        // Add btnHex2Dec
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 2;
        gbc.gridy = 0;
        SubCard4.add(btnHex2Dec, gbc);

        // Add btnBin2dec
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 3;
        gbc.gridy = 0;
        SubCard4.add(btnBin2Dec, gbc);

        // Add btnBin2Oct
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 4;
        gbc.gridy = 0;
        SubCard4.add(btnBin2Oct, gbc);

        // Add btn7
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 0;
        gbc.gridy = 1;
        SubCard4.add(btnSevenInNumberSystemConversion, gbc);

        // Add btn8
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 1;
        gbc.gridy = 1;
        SubCard4.add(btnEightInNumberSystemConversion,gbc);

        // Add btn9
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 2;
        gbc.gridy = 1;
        SubCard4.add(btnNineInNumberSystemConversion, gbc);

        // Add btnBin2hex
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 3;
        gbc.gridy = 1;
        SubCard4.add(btnBin2Hex, gbc);

        // Add btnOct2Dec
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 4;
        gbc.gridy = 1;
        SubCard4.add(btnOct2Dec, gbc);

        // Add btn4
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 0;
        gbc.gridy = 2;
        SubCard4.add(btnFourInNumberSystemConversion, gbc);

        // Add btn5
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 1;
        gbc.gridy = 2;
        SubCard4.add(btnFiveInNumberSystemConversion, gbc);

        // Add btn6
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 2;
        gbc.gridy = 2;
        SubCard4.add(btnSixInNumberSystemConversion, gbc);

        // Add btnOct2Bin
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 3;
        gbc.gridy = 2;
        SubCard4.add(btnOct2Bin, gbc);

        // Add btnOct2Hex
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 4;
        gbc.gridy = 2;
        SubCard4.add(btnOct2Hex, gbc);

        // Add btn1
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 0;
        gbc.gridy = 3;
        SubCard4.add(btnOneInNumberSystemConversion, gbc);

        // Add btn2
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 1;
        gbc.gridy = 3;
        SubCard4.add(btnTwoInNumberSystemConversion, gbc);

        //Add btn3
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 2;
        gbc.gridy = 3;
        SubCard4.add(btnThreeInNumberSystemConversion, gbc);

        // Add btnDec2Bin
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 3;
        gbc.gridy = 3;
        SubCard4.add(btnDec2Bin, gbc);

        // Add btnDec2Oct
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 4;
        gbc.gridy = 3;
        SubCard4.add(btnDec2Oct, gbc);

        // Add btn0
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 0;
        gbc.gridy = 4;
        SubCard4.add(btnA, gbc);

        // Add btn00
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 1;
        gbc.gridy = 4;
        SubCard4.add(btnZeroInNumberSystemConversion, gbc);

        // Add btnhex2Oct
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 2;
        gbc.gridy = 4;
        SubCard4.add(btnHex2Oct, gbc);

        // Add btnhex2Bin
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 3;
        gbc.gridy = 4;
        SubCard4.add(btnHex2Bin, gbc);

        // Add btnDec2Hex
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 4;
        gbc.gridy = 4;
        SubCard4.add(btnDec2Hex, gbc);

        // Add btnB
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 0;
        gbc.gridy = 5;
        SubCard4.add(btnB, gbc);

        // Add btnC
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 1;
        gbc.gridy = 5;
        SubCard4.add(btnC, gbc);

        // Add btnD
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 2;
        gbc.gridy = 5;
        SubCard4.add(btnD, gbc);

        // Add btnE
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 3;
        gbc.gridy = 5;
        SubCard4.add(btnE, gbc);

        // Add btnF
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(2,2,2,2);
        gbc.gridx = 4;
        gbc.gridy = 5;
        SubCard4.add(btnF, gbc);

    }
    private void createCards(){

        createArithmeticCard();
        createTrigonometryCard();
        createBitwiseCard();
        createBinaryArithmeticCard();
        createMoneyExchangeCard();
        createNumberSystemConversionCard();

        cards = new JPanel(new CardLayout());

        cards.add(ARITHMETICCARD, MainCard);
        cards.add(TRIGONOMETRYCARD, SubCard);
        cards.add(BITWISECARD, SubCard1);
        cards.add(BINARYARITHMETICCARD, SubCard2);
        cards.add(MONEYEXCHANGECARD, SubCard3);
        cards.add(NUMBERSYSTEMCONVERSIONCARD, SubCard4);

    }
    public MainFrame(){

        createCards();
        this.getContentPane().add(comboBox,BorderLayout.NORTH);
        this.getContentPane().add(cards, BorderLayout.SOUTH);
        this.getContentPane().add(txtResult, BorderLayout.CENTER);

        this.setSize(340,500);
        this.setTitle("ITE Calculator");
        this.setLocationRelativeTo(null);                           // this method display the JFrame to center position of a screen
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);

        // Generate icon from image for using as logo
        ImageIcon logo = new ImageIcon("src/images/calculator.jpg");
        setIconImage(logo.getImage());

    }
    @Override
    public void actionPerformed(ActionEvent e){
        // Performed action in Arithmetic panel
        if (e.getSource() == btnZeroInArithmetic){
            txtResult.setText(txtResult.getText().concat("0"));
        }
        if (e.getSource() == btnOneInArithmetic){
            txtResult.setText(txtResult.getText().concat("1"));
        }
        if (e.getSource() == btnTwoInArithmetic){
            txtResult.setText(txtResult.getText().concat("2"));
        }
        if (e.getSource() == btnThreeInArithmetic){
            txtResult.setText(txtResult.getText().concat("3"));
        }
        if (e.getSource() == btnFourInArithmetic){
            txtResult.setText(txtResult.getText().concat("4"));
        }
        if (e.getSource() == btnFiveInArithmetic){
            txtResult.setText(txtResult.getText().concat("5"));
        }
        if (e.getSource() == btnSixInArithmetic){
            txtResult.setText(txtResult.getText().concat("6"));
        }
        if (e.getSource() == btnSevenInArithmetic){
            txtResult.setText(txtResult.getText().concat("7"));
        }
        if (e.getSource() == btnEightInArithmetic){
            txtResult.setText(txtResult.getText().concat("8"));
        }
        if (e.getSource() == btnNineInArithmetic){
            txtResult.setText(txtResult.getText().concat("9"));
        }
        if (e.getSource() == btnDotInArithmetic){
            txtResult.setText(txtResult.getText().concat("."));
        }
        if (e.getSource() == btnAdditionInArithmetic){
            num1 = Double.parseDouble(txtResult.getText());
            Operator = "+";
            txtResult.setText("");
        }
        if (e.getSource() == btnDivisionInArithmetic){
            num1 = Double.parseDouble(txtResult.getText());
            Operator = "/";
            txtResult.setText("");
        }
        if (e.getSource() == btnModuloInArithmetic){
            num1 = Double.parseDouble(txtResult.getText());
            Operator = "%";
            txtResult.setText("");
        }
        if (e.getSource() == btnMultiplyInArithmetic){
            num1 = Double.parseDouble(txtResult.getText());
            Operator = "*";
            txtResult.setText("");
        }
        if (e.getSource() == btnSubtractionInArithmetic){
            num1 = Double.parseDouble(txtResult.getText());
            Operator = "-";
            txtResult.setText("");
        }
        if (e.getSource() == btnOneOverXInArithmetic){
            num1 = Double.parseDouble(txtResult.getText());
            result=1/num1;
            txtResult.setText(String.valueOf(result));
            num1 = result;
        }
        if (e.getSource() == btnX2InArithmetic){
            num1 = Double.parseDouble(txtResult.getText());
            result=num1*num1;
            txtResult.setText(String.valueOf(result));
            num1 = result;
        }
        if (e.getSource() == btnRadicalX2InArithmetic){
            num1 = Double.parseDouble(txtResult.getText());
            result=Math.sqrt(num1);
            txtResult.setText(String.valueOf(result));
            num1 = result;
        }
        if (e.getSource() == btnPlusMinusInArithmetic){
            num1 = Double.parseDouble(txtResult.getText());
            result = num1*-1;
            txtResult.setText(String.valueOf(result));
            num1 = result;
        }
        if (e.getSource() == btnEqualInArithmetic){
            num2=Double.parseDouble(txtResult.getText());

            switch (Operator) {
                case "+" -> result = num1 + num2;
                case "-" -> result = num1 - num2;
                case "*" -> result = num1 * num2;
                case "/" -> result = num1 / num2;
                case "%" -> result = num1 % num2;
            }
            txtResult.setText(String.valueOf(result));
            num1 = result;
        }
        if (e.getSource() == btnClearInArithmetic){
            txtResult.setText("");
        }
        if (e.getSource() == btnBackspaceInArithmetic){
            String string = txtResult.getText();
            txtResult.setText("");
            for (int i=0; i<string.length()-1; i++){
                txtResult.setText(txtResult.getText()+string.charAt(i));
            }
        }
        // Performed action in Trigonometry panel
        if (e.getSource() == btn0){
            txtResult.setText(txtResult.getText().concat("0"));
        }
        if (e.getSource() == btn00){
            txtResult.setText(txtResult.getText().concat("00"));
        }
        if (e.getSource() == btn1){
            txtResult.setText(txtResult.getText().concat("1"));
        }
        if (e.getSource() == btn2){
            txtResult.setText(txtResult.getText().concat("2"));
        }
        if (e.getSource() == btn3){
            txtResult.setText(txtResult.getText().concat("3"));
        }
        if (e.getSource() == btn4){
            txtResult.setText(txtResult.getText().concat("4"));
        }
        if (e.getSource() == btn5){
            txtResult.setText(txtResult.getText().concat("5"));
        }
        if (e.getSource() == btn6){
            txtResult.setText(txtResult.getText().concat("6"));
        }
        if (e.getSource() == btn7){
            txtResult.setText(txtResult.getText().concat("7"));
        }
        if (e.getSource() == btn8){
            txtResult.setText(txtResult.getText().concat("8"));
        }
        if (e.getSource() == btn9){
            txtResult.setText(txtResult.getText().concat("9"));
        }
        if (e.getSource() == btnDotSymbol){
            txtResult.setText(txtResult.getText().concat("."));
        }
        if (e.getSource() == btnAdditionSymbol){
            num1 = Double.parseDouble(txtResult.getText());
            Operator = "+";
            txtResult.setText("");
        }
        if (e.getSource() == btnDivisionSymbol){
            num1 = Double.parseDouble(txtResult.getText());
            Operator = "/";
            txtResult.setText("");
        }
        if (e.getSource() == btnModuloSymbol){
            num1 = Double.parseDouble(txtResult.getText());
            Operator = "%";
            txtResult.setText("");
        }
        if (e.getSource() == btnMultiplySymbol){
            num1 = Double.parseDouble(txtResult.getText());
            Operator = "*";
            txtResult.setText("");
        }
        if (e.getSource() == btnSubtractionSymbol){
            num1 = Double.parseDouble(txtResult.getText());
            Operator = "-";
            txtResult.setText("");
        }
        if (e.getSource() == btnOneOverX){
            num1 = Double.parseDouble(txtResult.getText());
            result=1/num1;
            txtResult.setText(String.valueOf(result));
            num1 = result;
        }
        if (e.getSource() == btnX2){
            num1 = Double.parseDouble(txtResult.getText());
            result=num1*num1;
            txtResult.setText(String.valueOf(result));
            num1 = result;
        }
        if (e.getSource() == btnRadicalX2){
            num1 = Double.parseDouble(txtResult.getText());
            result=Math.sqrt(num1);
            txtResult.setText(String.valueOf(result));
            num1 = result;
        }
        if (e.getSource() == btnSin){
            num1 = Double.parseDouble(txtResult.getText());
            result=Math.sin(Math.toRadians(num1));
            txtResult.setText(String.valueOf(result));
            num1 = result;
        }
        if (e.getSource() == btnCos){
            num1 = Double.parseDouble(txtResult.getText());
            result=Math.cos(Math.toRadians(num1));
            txtResult.setText(String.valueOf(result));
            num1 = result;
        }
        if (e.getSource() == btnCot){
            num1 = Double.parseDouble(txtResult.getText());
            result=1/Math.tan(Math.toRadians(num1));
            txtResult.setText(String.valueOf(result));
            num1 = result;
        }
        if (e.getSource() == btnTan){
            num1 = Double.parseDouble(txtResult.getText());
            result=Math.tan(Math.toRadians(num1));
            txtResult.setText(String.valueOf(result));
            num1 = result;
        }
        if (e.getSource() == btnPlusMinus){
            num1 = Double.parseDouble(txtResult.getText());
            result = num1*-1;
            txtResult.setText(String.valueOf(result));
            num1 = result;
        }
        if (e.getSource() == btnEqualSymbol){
            num2=Double.parseDouble(txtResult.getText());

            switch (Operator) {
                case "+" -> result = num1 + num2;
                case "-" -> result = num1 - num2;
                case "*" -> result = num1 * num2;
                case "/" -> result = num1 / num2;
                case "%" -> result = num1 % num2;
            }
            txtResult.setText(String.valueOf(result));
            num1 = result;
        }
        if (e.getSource() == btnClear){
            txtResult.setText("");
        }
        if (e.getSource() == btnBackspace){
            String string = txtResult.getText();
            txtResult.setText("");
            for (int i=0; i<string.length()-1; i++){
                txtResult.setText(txtResult.getText()+string.charAt(i));
            }
        }
        // perform action in bitwise panel
        if (e.getSource() == btnDoubleZeroInBitwise){
            txtResult.setText(txtResult.getText().concat("00"));
        }
        if (e.getSource() == btnZeroInBitwise){
            txtResult.setText(txtResult.getText().concat("0"));
        }
        if (e.getSource() == btnOneInBitwise){
            txtResult.setText(txtResult.getText().concat("1"));
        }
        if (e.getSource() == btnTwoInBitwise){
            txtResult.setText(txtResult.getText().concat("2"));
        }
        if (e.getSource() == btnThreeInBitwise){
            txtResult.setText(txtResult.getText().concat("3"));
        }
        if (e.getSource() == btnFourInBitwise){
            txtResult.setText(txtResult.getText().concat("4"));
        }
        if (e.getSource() == btnFiveInBitwise){
            txtResult.setText(txtResult.getText().concat("5"));
        }
        if (e.getSource() == btnSixInBitwise){
            txtResult.setText(txtResult.getText().concat("6"));
        }
        if (e.getSource() == btnSevenInBitwise){
            txtResult.setText(txtResult.getText().concat("7"));
        }
        if (e.getSource() == btnEightInBitwise){
            txtResult.setText(txtResult.getText().concat("8"));
        }
        if (e.getSource() == btnNineInBitwise){
            txtResult.setText(txtResult.getText().concat("9"));
        }
        if (e.getSource() == btnAndInBitwise){
            numA = Integer.parseInt(txtResult.getText());
            Operator = "AND";
            txtResult.setText("");
        }
        if (e.getSource() == btnOrInBitwise){
            numA = Integer.parseInt(txtResult.getText());
            Operator = "OR";
            txtResult.setText("");
        }
        if (e.getSource() == btnXorInBitwise){
            numA = Integer.parseInt(txtResult.getText());
            Operator = "XOR";
            txtResult.setText("");
        }
        if (e.getSource() == btnLeftShiftInBitwise){
            numA = Integer.parseInt(txtResult.getText());
            Operator = "<<";
            txtResult.setText("");
        }
        if (e.getSource() == btnRightShiftInBitwise){
            numA = Integer.parseInt(txtResult.getText());
            Operator = ">>";
            txtResult.setText("");
        }
        if (e.getSource() == btnInversionInBitwise){
            numA = Integer.parseInt(txtResult.getText());
            answer = ~numA;
            txtResult.setText(String.valueOf(answer));
            numA = answer;
        }
        if (e.getSource() == btnEqualInBitwise){
            numB = (int) Double.parseDouble(txtResult.getText());

            switch (Operator) {
                case "AND" -> answer = numA & numB;
                case "OR" -> answer = numA | numB;
                case "XOR" -> answer = numA ^ numB;
                case ">>" -> answer = numA >> numB;
                case "<<" -> answer = numA << numB;
            }
            txtResult.setText(String.valueOf(answer));
            numA = answer;
        }
        if (e.getSource() == btnClearInBitwise){
            txtResult.setText("");
        }
        if (e.getSource() == btnBackspaceInBitwise){
            String string = txtResult.getText();
            txtResult.setText("");
            for (int i=0; i<string.length()-1; i++){
                txtResult.setText(txtResult.getText()+string.charAt(i));
            }
        }
        // perform action in binaryArithmetic panel
        if (e.getSource() == btnZeroInBinaryArithmetic){
            txtResult.setText(txtResult.getText().concat("0"));
        }
        if (e.getSource() == btnOneInBinaryArithmetic){
            txtResult.setText(txtResult.getText().concat("1"));
        }
        if (e.getSource() == btnPlusInBinaryArithmetic){
            numA = Integer.parseInt(txtResult.getText(),2);
            Operator = "+";
            txtResult.setText("");
        }
        if (e.getSource() == btnMinusInBinaryArithmetic){
            numA = Integer.parseInt(txtResult.getText(),2);
            Operator = "-";
            txtResult.setText("");
        }
        if (e.getSource() == btnMultiplyInBinaryArithmetic){
            numA = Integer.parseInt(txtResult.getText(),2);
            Operator = "*";
            txtResult.setText("");
        }
        if (e.getSource() == btnDivisionInBinaryArithmetic){
            numA = Integer.parseInt(txtResult.getText(),2);
            Operator = "/";
            txtResult.setText("");
        }
        if (e.getSource() == btnEqualInBinaryArithmetic){
            numB =  Integer.parseInt(txtResult.getText(),2);

            switch (Operator) {
                case "+" -> answer = numA + numB;
                case "-" -> answer = numA - numB;
                case "*" -> answer = numA * numB;
                case "/" -> answer = numA / numB;
            }

            txtResult.setText(Integer.toBinaryString(answer));
            numA = answer;
        }
        if (e.getSource() == btnClearInBinaryArithmetic){
            txtResult.setText("");
        }
        if (e.getSource() == btnBackspaceInBinaryArithmetic){
            String string = txtResult.getText();
            txtResult.setText("");
            for (int i=0; i<string.length()-1; i++){
                txtResult.setText(txtResult.getText()+string.charAt(i));
            }
        }
        // perform action in Money_Exchange panel
        if (e.getSource() == btnDoubleZeroInMoneyExchange){
            txtResult.setText(txtResult.getText().concat("00"));
        }
        if (e.getSource() == btnZeroInMoneyExchange){
            txtResult.setText(txtResult.getText().concat("0"));
        }
        if (e.getSource() == btnOneInMoneyExchange){
            txtResult.setText(txtResult.getText().concat("1"));
        }
        if (e.getSource() == btnTwoInMoneyExchange){
            txtResult.setText(txtResult.getText().concat("2"));
        }
        if (e.getSource() == btnThreeInMoneyExchange){
            txtResult.setText(txtResult.getText().concat("3"));
        }
        if (e.getSource() == btnFourInMoneyExchange){
            txtResult.setText(txtResult.getText().concat("4"));
        }
        if (e.getSource() == btnFiveInMoneyExchange){
            txtResult.setText(txtResult.getText().concat("5"));
        }
        if (e.getSource() == btnSixInMoneyExchange){
            txtResult.setText(txtResult.getText().concat("6"));
        }
        if (e.getSource() == btnSevenInMoneyExchange){
            txtResult.setText(txtResult.getText().concat("7"));
        }
        if (e.getSource() == btnEightInMoneyExchange){
            txtResult.setText(txtResult.getText().concat("8"));
        }
        if (e.getSource() == btnNineInMoneyExchange){
            txtResult.setText(txtResult.getText().concat("9"));
        }
        if (e.getSource() == btnDotInMoneyExchange){
            txtResult.setText(txtResult.getText().concat("."));
        }
        if (e.getSource() == btnR2DInMoneyExchange){
            num1 = Double.parseDouble(txtResult.getText());
            result = num1 / 4050;
            txtResult.setText(String.valueOf(result));
            num1 = result;
        }
        if (e.getSource() == btnD2RInMoneyExchange){
            num1 = Double.parseDouble(txtResult.getText());
            result = num1 * 4050;
            txtResult.setText(String.valueOf(result));
            num1 = result;
        }
        if (e.getSource() == btnR2EInMoneyExchange){
            num1 = Double.parseDouble(txtResult.getText());
            result = num1 / 4673;
            txtResult.setText(String.valueOf(result));
            num1 = result;
        }
        if (e.getSource() == btnE2RInMoneyExchange){
            num1 = Double.parseDouble(txtResult.getText());
            result = num1 * 4673;
            txtResult.setText(String.valueOf(result));
            num1 = result;
        }
        if (e.getSource() == btnR2FInMoneyExchange){
            num1 = Double.parseDouble(txtResult.getText());
            result = num1 / 4500;
            txtResult.setText(String.valueOf(result));
            num1 = result;
        }
        if (e.getSource() == btnF2RInMoneyExchange){
            num1 = Double.parseDouble(txtResult.getText());
            result = num1 * 4500;
            txtResult.setText(String.valueOf(result));
            num1 = result;
        }
        if (e.getSource() == btnR2PInMoneyExchange){
            num1 = Double.parseDouble(txtResult.getText());
            result = num1 / 6000;
            txtResult.setText(String.valueOf(result));
            num1 = result;
        }
        if (e.getSource() == btnP2RInMoneyExchange){
            num1 = Double.parseDouble(txtResult.getText());
            result = num1 * 6000;
            txtResult.setText(String.valueOf(result));
            num1 = result;
        }
        if (e.getSource() == btnR2BInMoneyExchange){
            num1 = Double.parseDouble(txtResult.getText());
            result = num1 / 100;
            txtResult.setText(String.valueOf(result));
            num1 = result;
        }
        if (e.getSource() == btnB2RInMoneyExchange){
            num1 = Double.parseDouble(txtResult.getText());
            result = num1 * 100;
            txtResult.setText(String.valueOf(result));
            num1 = result;
        }
        if (e.getSource() == btnClearInMoneyExchange){
            txtResult.setText("");
        }
        if (e.getSource() == btnBackspaceInMoneyExchange){
            String string = txtResult.getText();
            txtResult.setText("");
            for (int i=0; i<string.length()-1; i++){
                txtResult.setText(txtResult.getText()+string.charAt(i));
            }
        }
        // perform action in Number_System_Conversion panel
        if (e.getSource() == btnZeroInNumberSystemConversion){
            txtResult.setText(txtResult.getText().concat("0"));
        }
        if (e.getSource() == btnDoubleZeroInNumberSystemConversion){
            txtResult.setText(txtResult.getText().concat("00"));
        }
        if (e.getSource() == btnOneInNumberSystemConversion){
            txtResult.setText(txtResult.getText().concat("1"));
        }
        if (e.getSource() == btnTwoInNumberSystemConversion){
            txtResult.setText(txtResult.getText().concat("2"));
        }
        if (e.getSource() == btnThreeInNumberSystemConversion){
            txtResult.setText(txtResult.getText().concat("3"));
        }
        if (e.getSource() == btnFourInNumberSystemConversion){
            txtResult.setText(txtResult.getText().concat("4"));
        }
        if (e.getSource() == btnFiveInNumberSystemConversion){
            txtResult.setText(txtResult.getText().concat("5"));
        }
        if (e.getSource() == btnSixInNumberSystemConversion){
            txtResult.setText(txtResult.getText().concat("6"));
        }
        if (e.getSource() == btnSevenInNumberSystemConversion){
            txtResult.setText(txtResult.getText().concat("7"));
        }
        if (e.getSource() == btnEightInNumberSystemConversion){
            txtResult.setText(txtResult.getText().concat("8"));
        }
        if (e.getSource() == btnNineInNumberSystemConversion){
            txtResult.setText(txtResult.getText().concat("9"));
        }
        if (e.getSource() == btnA){
            txtResult.setText(txtResult.getText().concat("a"));
        }
        if (e.getSource() == btnB){
            txtResult.setText(txtResult.getText().concat("b"));
        }
        if (e.getSource() == btnC){
            txtResult.setText(txtResult.getText().concat("c"));
        }
        if (e.getSource() == btnD){
            txtResult.setText(txtResult.getText().concat("d"));
        }
        if (e.getSource() == btnE){
            txtResult.setText(txtResult.getText().concat("e"));
        }
        if (e.getSource() == btnF) {
            txtResult.setText(txtResult.getText().concat("f"));
        }
        if (e.getSource() == btnClearInNumberSystemConversion){
            txtResult.setText("");
        }
        if (e.getSource() == btnBackspaceInNumberSystemConversion){
            String string = txtResult.getText();
            txtResult.setText("");
            for (int i=0; i<string.length()-1; i++){
                txtResult.setText(txtResult.getText()+string.charAt(i));
            }
        }
        if (e.getSource() == btnDec2Bin){
            numA = Integer.parseInt(txtResult.getText());
            stringAnswers = Integer.toBinaryString(numA);
            txtResult.setText(stringAnswers);
        }
        if (e.getSource() == btnDec2Oct){
            numA = Integer.parseInt(txtResult.getText());
            stringAnswers = Integer.toOctalString(numA);
            txtResult.setText(stringAnswers);
        }
        if (e.getSource() == btnDec2Hex){
            numA = Integer.parseInt(txtResult.getText());
            stringAnswers = Integer.toHexString(numA);
            txtResult.setText(stringAnswers);
        }
        if (e.getSource() == btnBin2Dec){
            stringAnswers = txtResult.getText();
            numA = Integer.parseInt(stringAnswers,2);
            txtResult.setText(String.valueOf(numA));
        }
        if (e.getSource() == btnBin2Oct){
            stringAnswers = txtResult.getText();
            numA = Integer.parseInt(stringAnswers,2);
            stringOctal = Integer.toOctalString(numA);
            txtResult.setText(stringOctal);
        }
        if (e.getSource() == btnOct2Bin){
            stringAnswers = txtResult.getText();
            numA = Integer.parseInt(stringAnswers,8);
            stringAnswers = Integer.toBinaryString(numA);
            txtResult.setText(stringAnswers);
        }
        if (e.getSource() == btnOct2Hex){
            stringAnswers = txtResult.getText();
            numA = Integer.parseInt(stringAnswers,8);
            stringAnswers = Integer.toHexString(numA);
            txtResult.setText(stringAnswers);
        }
        if (e.getSource() == btnOct2Dec){
            stringAnswers = txtResult.getText();
            numA = Integer.parseInt(stringAnswers,8);
            txtResult.setText(String.valueOf(numA));
        }
        if (e.getSource() == btnHex2Bin){
            stringAnswers = txtResult.getText();
            numA = Integer.parseInt(stringAnswers,16);
            stringAnswers = Integer.toBinaryString(numA);
            txtResult.setText(stringAnswers);
        }
        if (e.getSource() == btnHex2Oct){
            stringAnswers = txtResult.getText();
            numA = Integer.parseInt(stringAnswers,16);
            stringAnswers = Integer.toOctalString(numA);
            txtResult.setText(stringAnswers);
        }
        if (e.getSource() == btnHex2Dec){
            stringAnswers = txtResult.getText();
            numA = Integer.parseInt(stringAnswers,16);
            txtResult.setText(String.valueOf(numA));
        }

        if (e.getSource() == comboBox) {
            comboBox = (JComboBox) e.getSource();
            CardLayout cardLayout = (CardLayout) cards.getLayout();
            cardLayout.show(cards, comboBox.getSelectedItem().toString());
        }
    }
}
